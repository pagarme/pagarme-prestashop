<?php

class OrderPayment extends OrderPaymentCore
{}